﻿using System;

namespace NameAndAge
{
    class Program
    {
        static void Main(string[] args)
        {
            Person firstPerson = new Person();
            
        }
    }
}
